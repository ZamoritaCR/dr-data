$folder = Split-Path -Parent $MyInvocation.MyCommand.Path
$folder = $folder + "\"
Get-ChildItem -Path $folder -Recurse -Filter "*.tmdl" | ForEach-Object {
    $c = [IO.File]::ReadAllText($_.FullName)
    if ($c.Contains("C:\PBI_Data\")) {
        $c = $c.Replace("C:\PBI_Data\", $folder)
        [IO.File]::WriteAllText($_.FullName, $c)
        Write-Host "  Updated:" $_.Name
    }
}
