Power BI Project: Dashboard 1
================================

HOW TO OPEN:
  1. Extract this entire ZIP to a folder on your computer
  2. Double-click: Open_Dashboard.bat
     (This sets up the data source path and opens Power BI)

REQUIREMENTS:
  - Power BI Desktop (January 2026 or later)
  - Enable preview features if not already enabled:
    File > Options > Preview features > check all PBIP options

FILES:
  Open_Dashboard.bat        -- Double-click this to open
  Dashboard_1.pbip               -- Power BI project file
  Dashboard_1.Report/            -- Report layout, pages, visuals
  Dashboard_1.SemanticModel/     -- Data model, DAX measures
