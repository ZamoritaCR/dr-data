@echo off
cd /d "%~dp0"
echo Setting up data source path...
powershell -NoProfile -ExecutionPolicy Bypass -File "setup.ps1"
echo.
echo Opening Pipeline_activity_1.pbip in Power BI Desktop...
start "" "Pipeline_activity_1.pbip"
